--------------------
StaticElController
--------------------
Version: 1.2.0-pl
Author: Culture Foundry <andrew@culturefoundry.com>
--------------------

StaticElController is a plugin for MODx Revolution that sets the path of the file and media 
resource of element (template, chunk, snippet, or plugin) when the 
"isStatic" checkbox is checked, and locks code editor if the element 
is static.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/culturefoundry/static_el_controller/issues